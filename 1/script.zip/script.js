let name = 'Василь';
let admin = name;
console.log(admin);